import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

PAYMENT_QR = "payment_qr.png"
UPI_ID = "6290211218@fam"

PRODUCTS = {
    "king": {"name": "👑 AIM CARROM KING", "plans": [
        ("AUTOPLAY NORMAL", [("3 Days",250),("1 Week",450),("1 Month",1250),("3 Months",2500)]),
        ("AUTOPLAY QUEUE", [("3 Days",350),("1 Week",550),("1 Month",1450),("3 Months",3000)])]},
    "snake": {"name": "🐍 SNAKE ENGINE", "plans": [
        ("AUTOPLAY", [("3 Days",200),("10 Days",500),("30 Days",1100),("90 Days",2600)])]},
    "aimai": {"name": "🤖 AIM AI ENGINE", "plans": [
        ("AUTOPLAY", [("1 Day",120),("3 Days",200),("7 Days",300),("15 Days",500),("30 Days",850),("90 Days",2100)])]},
    "kos": {"name": "🎱 KOS ENGINE", "plans": [
        ("AUTOPLAY", [("1 Day",110),("7 Days",350),("15 Days",570),("30 Days",990)])]},
    "bitaim": {"name": "🔵 BITAIM+ PREMIUM", "plans": [
        ("LINES", [("1 Week",70),("1 Month",170),("3 Months",360),("Lifetime",1999)])]},
    "lynx": {"name": "🔴 LYNX CHEATS", "plans": [
        ("AUTOPLAY", [("1 Day",110),("3 Days",190),("7 Days",330),("15 Days",540),("30 Days",880)])]},
}

def home_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🛍️ PRODUCTS", callback_data="products")],
        [InlineKeyboardButton("📦 MY ORDERS", callback_data="orders"),
         InlineKeyboardButton("💳 PAYMENT", callback_data="payment")],
        [InlineKeyboardButton("🎮 PLAY CARROM", callback_data="carrom")],
        [InlineKeyboardButton("📜 RULES", callback_data="rules"),
         InlineKeyboardButton("💬 HELP", callback_data="help")],
    ])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "👑 APEX GAMING SHOP\n\nWelcome! 🛍️\nChoose an option below:",
        reply_markup=home_keyboard()
    )

async def products(update, context):
    q = update.callback_query
    await q.answer()
    buttons = [[InlineKeyboardButton(p["name"], callback_data=f"product_{k}")]
               for k,p in PRODUCTS.items()]
    buttons.append([InlineKeyboardButton("🔙 HOME", callback_data="home")])
    await q.edit_message_text("🛍️ SELECT A PRODUCT:", reply_markup=InlineKeyboardMarkup(buttons))

async def product_details(update, context):
    q = update.callback_query
    await q.answer()
    key = q.data.replace("product_", "")
    p = PRODUCTS[key]
    text = f"{p['name']}\n\n"
    buttons = []
    for category, plans in p["plans"]:
        text += f"🔹 {category}\n"
        for i,(duration,price) in enumerate(plans):
            text += f"• {duration} — ₹{price}\n"
            buttons.append([InlineKeyboardButton(
                f"🛒 BUY {duration} ₹{price}",
                callback_data=f"buy_{key}_{i}_{category.replace(' ','_')}"
            )])
        text += "\n"
    buttons.append([InlineKeyboardButton("🔙 PRODUCTS", callback_data="products")])
    await q.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons))

async def buy(update, context):
    q = update.callback_query
    await q.answer()
    parts = q.data.split("_")
    key, index = parts[1], int(parts[2])
    p = PRODUCTS[key]
    selected_category = None
    selected_plan = None
    for category, plans in p["plans"]:
        if parts[3] == category.replace(" ","_"):
            selected_category = category
            selected_plan = plans[index]
            break
    if not selected_plan:
        await q.edit_message_text("❌ Plan not found.")
        return
    duration, price = selected_plan
    context.user_data["last_order"] = {
        "product": p["name"], "plan": selected_category,
        "duration": duration, "price": price
    }
    await q.edit_message_text(
        f"🛒 ORDER DETAILS\n\nProduct: {p['name']}\nPlan: {selected_category}\n"
        f"Duration: {duration}\nPrice: ₹{price}\n\n"
        "💳 Pay using the PAYMENT button below.\n"
        "After payment, send the payment proof to support.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💳 PAY NOW / SCAN QR", callback_data="payment")],
            [InlineKeyboardButton("💬 CONTACT SUPPORT", callback_data="help")],
            [InlineKeyboardButton("🔙 PRODUCTS", callback_data="products")],
        ])
    )

async def payment(update, context):
    q = update.callback_query
    await q.answer()
    order = context.user_data.get("last_order")
    caption = (
        "💳 APEX GAMING SHOP — PAYMENT\n\n"
        f"UPI ID: {UPI_ID}\n\n"
        "📱 Scan the QR to pay.\n"
        "After payment, send the payment screenshot/proof to support.\n\n"
        "⚠️ Payment is verified manually."
    )
    if order:
        caption += f"\n\n🛒 Current order: {order['product']}\n💰 Amount: ₹{order['price']}"
    try:
        await q.message.delete()
    except Exception:
        pass
    if os.path.exists(PAYMENT_QR):
        await context.bot.send_photo(
            chat_id=q.message.chat_id,
            photo=open(PAYMENT_QR, "rb"),
            caption=caption,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💬 SEND PAYMENT PROOF / HELP", callback_data="help")],
                [InlineKeyboardButton("🛍️ PRODUCTS", callback_data="products"),
                 InlineKeyboardButton("🏠 HOME", callback_data="home")],
            ])
        )
    else:
        await context.bot.send_message(
            chat_id=q.message.chat_id,
            text=caption + "\n\n❌ QR image is missing from the bot files.",
            reply_markup=home_keyboard()
        )

async def orders(update, context):
    q = update.callback_query
    await q.answer()
    order = context.user_data.get("last_order")
    if order:
        text = (f"📦 MY ORDERS\n\n{order['product']}\n"
                f"{order['plan']} • {order['duration']} • ₹{order['price']}\n\n"
                "Status: Payment proof pending verification.")
    else:
        text = "📦 MY ORDERS\n\nYou don't have any orders yet."
    await q.edit_message_text(text, reply_markup=InlineKeyboardMarkup([
        [InlineKeyboardButton("🛍️ PRODUCTS", callback_data="products")],
        [InlineKeyboardButton("💳 PAYMENT", callback_data="payment")],
        [InlineKeyboardButton("🔙 HOME", callback_data="home")],
    ]))

async def carrom(update, context):
    q = update.callback_query
    await q.answer()
    await q.edit_message_text(
        "🎮 PLAY CARROM\n\nCarrom game section is available from the bot menu.",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 HOME", callback_data="home")]])
    )

async def rules(update, context):
    q = update.callback_query
    await q.answer()
    await q.edit_message_text(
        "📜 SHOP RULES\n\n"
        "1️⃣ Check product and plan carefully.\n"
        "2️⃣ Pay the exact amount shown.\n"
        "3️⃣ Send payment proof after payment.\n"
        "4️⃣ Orders are processed after verification.\n"
        "5️⃣ Contact support if there is any issue.",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 HOME", callback_data="home")]])
    )

async def help_command(update, context):
    q = update.callback_query
    text = "💬 HELP & SUPPORT\n\nSend your order/payment proof here and contact the shop administrator for verification."
    if q:
        await q.answer()
        await q.edit_message_text(text, reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💳 PAYMENT", callback_data="payment")],
            [InlineKeyboardButton("🔙 HOME", callback_data="home")],
        ]))
    else:
        await update.message.reply_text(text, reply_markup=home_keyboard())

async def home(update, context):
    q = update.callback_query
    await q.answer()
    await q.edit_message_text("👑 APEX GAMING SHOP\n\nChoose an option:", reply_markup=home_keyboard())

async def callback_handler(update, context):
    data = update.callback_query.data
    if data == "products": await products(update, context)
    elif data.startswith("product_"): await product_details(update, context)
    elif data.startswith("buy_"): await buy(update, context)
    elif data == "payment": await payment(update, context)
    elif data == "orders": await orders(update, context)
    elif data == "carrom": await carrom(update, context)
    elif data == "rules": await rules(update, context)
    elif data == "help": await help_command(update, context)
    elif data == "home": await home(update, context)

def main():
    token = os.environ.get("BOT_TOKEN")
    if not token:
        raise RuntimeError("BOT_TOKEN is missing")
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CallbackQueryHandler(callback_handler))
    print("APEX GAMING SHOP BOT is starting...")
    app.run_polling()

if __name__ == "__main__":
    main()
